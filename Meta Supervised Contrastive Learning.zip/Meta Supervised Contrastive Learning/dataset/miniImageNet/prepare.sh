tar -xzf MiniImagenet.tar.gz
python from_pickle_to_folder.py
